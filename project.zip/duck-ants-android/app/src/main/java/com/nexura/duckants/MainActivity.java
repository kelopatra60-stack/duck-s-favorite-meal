package com.nexura.duckants;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.View;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private DuckServer srv;
    private WebView wv;
    private WifiManager.MulticastLock ml;
    private WifiManager.WifiLock wfl;
    private PowerManager.WakeLock wl;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        int port = 0;
        try {
            InputStream is = getAssets().open("index.html");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[65536]; int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            is.close();
            byte[] html = bo.toByteArray();
            for (int p = 8080; p < 8090 && port == 0; p++) {
                try { DuckServer s = new DuckServer(p, html); s.start(); srv = s; port = p; } catch (Exception e) { /* المنفذ مشغول: جرّب التالي */ }
            }
        } catch (Exception e) { /* تجاهل */ }
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            ml = wm.createMulticastLock("duckants");
            ml.setReferenceCounted(false);
            ml.acquire();
            wfl = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "duckants:wf");
            wfl.setReferenceCounted(false);
            wfl.acquire();
        } catch (Exception e) { /* اختياري */ }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "duckants:wl");
            wl.setReferenceCounted(false);
            wl.acquire();
        } catch (Exception e) { /* اختياري */ }
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                runOnUiThread(new Runnable() { public void run() { recreate(); } });
                return true;
            }
        });
        wv.loadUrl("http://127.0.0.1:" + (port == 0 ? 8080 : port) + "/");
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onBackPressed() {
        if (wv == null) { finish(); return; }
        wv.evaluateJavascript("(function(){return window.__back?window.__back():0})()", new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) { if (!"1".equals(v)) finish(); }
        });
    }

    @Override
    protected void onDestroy() {
        if (srv != null) srv.stop();
        try { if (ml != null && ml.isHeld()) ml.release(); } catch (Exception e) { }
        try { if (wfl != null && wfl.isHeld()) wfl.release(); } catch (Exception e) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) { }
        if (wv != null) wv.destroy();
        super.onDestroy();
    }
}
