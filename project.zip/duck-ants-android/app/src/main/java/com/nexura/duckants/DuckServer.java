package com.nexura.duckants;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPOutputStream;

/** خادم لعبة البطة والنمل: HTTP + WebSocket + اكتشاف الغرف على الشبكة المحلية. بدون أي مكتبات خارجية. */
public class DuckServer {
    static final int MAXP = 12, MAXMSG = 16384, RATE = 80;
    static final long GRACE = 8000;
    static final String GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    static final Random RND = new Random();

    final int port;
    final byte[] gameGz;
    final Object lock = new Object();
    final Map<String, Room> rooms = new HashMap<>();
    final Set<Conn> conns = ConcurrentHashMap.newKeySet();
    final Map<String, Seen> seen = new ConcurrentHashMap<>();
    ServerSocket ss;
    volatile boolean run;
    DatagramSocket rx;

    static class Room { String code, host, hn = ""; int pc = 1, ph = 0; final Map<String, Member> members = new HashMap<>(); }
    static class Member { Conn c; String tok; long gone; }
    static class Seen { String ip, c, hn; int pc, port; long ts; }

    public DuckServer(int port, byte[] html) throws IOException {
        this.port = port;
        String h = new String(html, StandardCharsets.UTF_8);
        h = h.replaceFirst("<head>", "<head><script>window.DUCK_APP=1</script><link rel=\"manifest\" href=\"/manifest.webmanifest\"><meta name=\"mobile-web-app-capable\" content=\"yes\">");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (GZIPOutputStream gz = new GZIPOutputStream(bo)) { gz.write(h.getBytes(StandardCharsets.UTF_8)); }
        gameGz = bo.toByteArray();
    }

    // ------------------------------------------------------------------ تشغيل
    public void start() throws IOException {
        ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress("0.0.0.0", port));
        run = true;
        daemon("accept", () -> { while (run) { try { Socket s = ss.accept(); daemon("conn", () -> serve(s)); } catch (IOException e) { if (!run) break; } } });
        daemon("sweep", () -> { while (run) { sleep(1000); sweep(); } });
        daemon("ping", () -> { while (run) { sleep(20000); for (Conn c : conns) { if (!c.alive) { c.close(); continue; } c.alive = false; c.raw(frame(9, new byte[0])); } } });
        startDiscovery();
    }
    public void stop() { run = false; try { ss.close(); } catch (Exception e) {} try { if (rx != null) rx.close(); } catch (Exception e) {} for (Conn c : conns) c.close(); }
    static void daemon(String n, final Runnable r) { Thread t = new Thread(new Runnable() { public void run() { try { r.run(); } catch (Throwable e) { /* لا نسمح لأي خطأ بإسقاط التطبيق */ } } }, "duck-" + n); t.setDaemon(true); t.start(); }
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) {} }

    // ------------------------------------------------------------------ اتصال
    class Conn {
        final Socket sock; final DataInputStream in; final OutputStream out;
        final BlockingQueue<byte[]> q = new LinkedBlockingQueue<>(256);
        volatile boolean dead, alive = true, sub; String id = "", room; long rt; int rn; final boolean loopback; final String ip;
        Conn(Socket s) throws IOException {
            sock = s; in = new DataInputStream(new BufferedInputStream(s.getInputStream())); out = s.getOutputStream();
            ip = s.getInetAddress().getHostAddress(); loopback = s.getInetAddress().isLoopbackAddress();
            s.setTcpNoDelay(true);
        }
        void startWriter() {
            daemon("w", () -> { try { while (!dead) { byte[] b = q.poll(1, TimeUnit.SECONDS); if (b != null) { out.write(b); out.flush(); } } } catch (Exception e) { close(); } });
        }
        void raw(byte[] b) { if (!dead) q.offer(b); }
        void send(String json) { raw(frame(1, json.getBytes(StandardCharsets.UTF_8))); }
        void close() { if (dead) return; dead = true; conns.remove(this); try { sock.close(); } catch (Exception e) {} onDrop(this); }
    }

    // ------------------------------------------------------------------ HTTP / WS
    void serve(Socket s) {
        try {
            s.setSoTimeout(15000);
            InputStream is = new BufferedInputStream(s.getInputStream());
            ByteArrayOutputStream hb = new ByteArrayOutputStream(); int st = 0, b;
            while (hb.size() < 8192 && (b = is.read()) >= 0) { hb.write(b); st = (b == '\r' || b == '\n') ? st + 1 : 0; if (st >= 4 && b == '\n') break; }
            String[] lines = hb.toString("UTF-8").split("\r\n");
            if (lines.length == 0) { s.close(); return; }
            String[] rl = lines[0].split(" ");
            Map<String, String> h = new HashMap<>();
            for (int i = 1; i < lines.length; i++) { int k = lines[i].indexOf(':'); if (k > 0) h.put(lines[i].substring(0, k).trim().toLowerCase(), lines[i].substring(k + 1).trim()); }
            String path = rl.length > 1 ? rl[1].split("\\?")[0] : "/";
            if ("websocket".equalsIgnoreCase(h.get("upgrade")) && h.get("sec-websocket-key") != null) { upgrade(s, h.get("sec-websocket-key")); return; }
            OutputStream os = s.getOutputStream();
            if (path.equals("/health")) { String j = "{\"ok\":1,\"rooms\":" + rooms.size() + ",\"conns\":" + conns.size() + "}"; http(os, "application/json", j.getBytes(StandardCharsets.UTF_8), false); }
            else if (path.equals("/rooms")) http(os, "application/json", roomsJson().getBytes(StandardCharsets.UTF_8), false);
            else if (path.equals("/manifest.webmanifest")) http(os, "application/manifest+json", "{\"name\":\"البطة والنمل\",\"short_name\":\"البطة والنمل\",\"start_url\":\"/\",\"display\":\"fullscreen\",\"orientation\":\"landscape\",\"background_color\":\"#3e2415\",\"theme_color\":\"#3e2415\"}".getBytes(StandardCharsets.UTF_8), false);
            else if (path.equals("/") || path.equals("/index.html")) http(os, "text/html; charset=utf-8", gameGz, true);
            else http(os, "text/plain; charset=utf-8", "Duck & Ants".getBytes(StandardCharsets.UTF_8), false);
            os.flush(); s.close();
        } catch (Exception e) { try { s.close(); } catch (Exception x) {} }
    }
    static void http(OutputStream os, String type, byte[] body, boolean gz) throws IOException {
        os.write(("HTTP/1.1 200 OK\r\nContent-Type: " + type + "\r\n" + (gz ? "Content-Encoding: gzip\r\nCache-Control: no-cache\r\n" : "") + "Content-Length: " + body.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        os.write(body);
    }
    void upgrade(Socket s, String key) throws Exception {
        String acc = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest((key + GUID).getBytes(StandardCharsets.UTF_8)));
        s.getOutputStream().write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        s.getOutputStream().flush();
        s.setSoTimeout(0);
        Conn c = new Conn(s); conns.add(c); c.startWriter();
        try { wsLoop(c); } catch (Exception e) { /* انقطاع */ } finally { c.close(); }
    }
    static byte[] frame(int op, byte[] p) {
        int n = p.length; ByteArrayOutputStream o = new ByteArrayOutputStream(n + 10);
        o.write(0x80 | op);
        if (n < 126) o.write(n); else if (n < 65536) { o.write(126); o.write(n >> 8); o.write(n & 255); }
        else { o.write(127); for (int i = 7; i >= 0; i--) o.write((int) (((long) n) >> (8 * i)) & 255); }
        o.write(p, 0, n); return o.toByteArray();
    }
    void wsLoop(Conn c) throws IOException {
        DataInputStream in = c.in; ByteArrayOutputStream frag = null;
        while (!c.dead) {
            int b0 = in.read(); if (b0 < 0) break; int b1 = in.read(); if (b1 < 0) break;
            int op = b0 & 15; boolean fin = (b0 & 0x80) != 0, masked = (b1 & 0x80) != 0; long len = b1 & 127;
            if (len == 126) len = in.readUnsignedShort(); else if (len == 127) len = in.readLong();
            if (len > MAXMSG || len < 0 || !masked) break;
            byte[] mk = new byte[4]; in.readFully(mk); byte[] pl = new byte[(int) len]; in.readFully(pl);
            for (int i = 0; i < pl.length; i++) pl[i] ^= mk[i & 3];
            c.alive = true;
            if (op == 8) break;
            if (op == 9) { c.raw(frame(10, pl)); continue; }
            if (op == 10) continue;
            if (op == 1 || op == 0) {
                if (!fin) { if (frag == null) frag = new ByteArrayOutputStream(); frag.write(pl); if (frag.size() > MAXMSG) break; continue; }
                byte[] full = pl; if (frag != null) { frag.write(pl); full = frag.toByteArray(); frag = null; }
                handle(c, new String(full, StandardCharsets.UTF_8));
            }
        }
    }

    // ------------------------------------------------------------------ منطق الغرف
    static String q(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char ch : s.toCharArray()) { if (ch == '"' || ch == '\\') b.append('\\').append(ch); else if (ch < 32) b.append(' '); else b.append(ch); }
        return b.append('"').toString();
    }
    static String sget(Map<String, Object> m, String k) { Object o = m.get(k); return o == null ? "" : (o instanceof Double && ((Double) o) == Math.rint((Double) o) ? String.valueOf(((Double) o).longValue()) : String.valueOf(o)); }
    static int iget(Map<String, Object> m, String k) { Object o = m.get(k); return o instanceof Double ? ((Double) o).intValue() : 0; }
    Conn hostConn(Room r) { Member m = r.members.get(r.host); return m == null ? null : m.c; }
    String newCode() { String c; do c = String.valueOf(1000 + RND.nextInt(9000)); while (rooms.containsKey(c)); return c; }
    String newId() { return Long.toHexString(RND.nextLong() & 0xffffffffffL) + Integer.toHexString(RND.nextInt(4096)); }

    void handle(Conn c, String s) {
        long now = System.currentTimeMillis();
        if (now - c.rt > 1000) { c.rt = now; c.rn = 0; }
        if (++c.rn > RATE) return;
        Json j; try { j = new Json(s); } catch (Exception e) { return; }
        if (j.top == null) return;
        Map<String, Object> m = j.top; String t = sget(m, "t");
        synchronized (lock) {
            Room r = c.room == null ? null : rooms.get(c.room);
            switch (t) {
                case "list": c.sub = true; c.send("{\"t\":\"rooms\",\"rooms\":" + roomsJson() + "}"); break;
                case "host": {
                    if (c.room != null || !c.loopback || rooms.size() > 50) { c.send("{\"t\":\"err\",\"m\":\"busy\"}"); break; }
                    String code = sget(m, "c"); if (!code.matches("\\d{4}")) code = newCode();
                    if (rooms.containsKey(code)) { c.send("{\"t\":\"err\",\"m\":\"taken\"}"); break; }
                    Room nr = new Room(); nr.code = code; nr.host = newId(); rooms.put(code, nr);
                    String tok = join(c, nr, nr.host);
                    c.send("{\"t\":\"hosted\",\"c\":" + q(code) + ",\"id\":" + q(nr.host) + ",\"tok\":" + q(tok) + "}");
                    break; }
                case "join": {
                    if (c.room != null) break;
                    Room tr = rooms.get(sget(m, "c"));
                    if (tr == null || hostConn(tr) == null) { c.send("{\"t\":\"err\",\"m\":\"none\"}"); break; }
                    if (tr.members.size() >= MAXP) { c.send("{\"t\":\"err\",\"m\":\"full\"}"); break; }
                    String id; do id = newId(); while (tr.members.containsKey(id));
                    String tok = join(c, tr, id);
                    c.send("{\"t\":\"joined\",\"c\":" + q(tr.code) + ",\"id\":" + q(id) + ",\"tok\":" + q(tok) + ",\"host\":" + q(tr.host) + "}");
                    hostConn(tr).send("{\"t\":\"join\",\"id\":" + q(id) + "}");
                    break; }
                case "resume": {
                    Room tr = rooms.get(sget(m, "c")); Member mem = tr == null ? null : tr.members.get(sget(m, "id"));
                    if (mem == null || !mem.tok.equals(sget(m, "tok"))) { c.send("{\"t\":\"err\",\"m\":\"gone\"}"); break; }
                    if (mem.c != null && !mem.c.dead) { mem.c.room = null; mem.c.close(); }
                    mem.c = c; mem.gone = 0; c.id = sget(m, "id"); c.room = tr.code; c.send("{\"t\":\"resumed\"}");
                    break; }
                case "p": {
                    if (r == null || c.id.equals(r.host) || j.rawD == null || !j.rawD.startsWith("{")) break;
                    Conn hc = hostConn(r); if (hc != null) hc.send("{\"t\":\"p\",\"id\":" + q(c.id) + ",\"d\":" + j.rawD + "}");
                    break; }
                case "st": {
                    if (r == null || !c.id.equals(r.host) || j.rawD == null) break;
                    byte[] fr = frame(1, ("{\"t\":\"st\",\"d\":" + j.rawD + "}").getBytes(StandardCharsets.UTF_8));
                    for (Map.Entry<String, Member> e : r.members.entrySet()) if (!e.getKey().equals(r.host) && e.getValue().c != null) e.getValue().c.raw(fr);
                    break; }
                case "info": {
                    if (r == null || !c.id.equals(r.host)) break;
                    r.pc = Math.max(1, Math.min(MAXP, iget(m, "pc"))); r.hn = sget(m, "hn").replaceAll("[<>&\"'`\\\\]", "").trim(); if (r.hn.length() > 10) r.hn = r.hn.substring(0, 10); r.ph = iget(m, "ph");
                    break; }
                case "leave": if (r != null) removeMember(r, c.id); break;
                default: break;
            }
        }
    }
    String join(Conn c, Room r, String id) { Member mm = new Member(); mm.c = c; mm.tok = newId() + newId(); r.members.put(id, mm); c.id = id; c.room = r.code; return mm.tok; }
    void removeMember(Room r, String id) {
        if (id.equals(r.host)) { for (Map.Entry<String, Member> e : r.members.entrySet()) if (!e.getKey().equals(r.host) && e.getValue().c != null) { e.getValue().c.room = null; e.getValue().c.send("{\"t\":\"closed\"}"); } rooms.remove(r.code); return; }
        Member m = r.members.remove(id); if (m != null && m.c != null) m.c.room = null;
        Conn hc = hostConn(r); if (hc != null) hc.send("{\"t\":\"leave\",\"id\":" + q(id) + "}");
    }
    void onDrop(Conn c) {
        synchronized (lock) {
            Room r = c.room == null ? null : rooms.get(c.room); Member m = r == null ? null : r.members.get(c.id);
            if (m != null && m.c == c) { m.c = null; m.gone = System.currentTimeMillis(); }
        }
    }
    void sweep() {
        long now = System.currentTimeMillis();
        synchronized (lock) {
            for (Room r : new ArrayList<>(rooms.values())) for (Map.Entry<String, Member> e : new ArrayList<>(r.members.entrySet()))
                if (e.getValue().gone > 0 && now - e.getValue().gone > GRACE) { if (!rooms.containsKey(r.code)) break; removeMember(r, e.getKey()); }
        }
    }
    String roomsJson() {   // الغرف القريبة المكتشفة على الشبكة (غير اللاعب نفسه إن أمكن)
        long now = System.currentTimeMillis(); StringBuilder b = new StringBuilder("["); boolean f = true;
        for (Seen s : seen.values()) {
            if (now - s.ts > 4000) { seen.remove(s.ip + ":" + s.c); continue; }
            if (!f) b.append(','); f = false;
            b.append("{\"c\":").append(q(s.c)).append(",\"hn\":").append(q(s.hn)).append(",\"pc\":").append(s.pc).append(",\"ip\":").append(q(s.ip)).append(",\"p\":").append(s.port).append('}');
        }
        return b.append(']').toString();
    }

    // ------------------------------------------------------------------ اكتشاف الغرف (UDP)
    void startDiscovery() {
        final int dport = Integer.getInteger("duck.disc", 8081);
        try {
            rx = new DatagramSocket(null); rx.setReuseAddress(true); rx.setBroadcast(true); rx.bind(new InetSocketAddress(dport));
            daemon("disc-rx", () -> { byte[] buf = new byte[1024]; while (run) { try { DatagramPacket p = new DatagramPacket(buf, buf.length); rx.receive(p);
                if (!Boolean.getBoolean("duck.allowSelf")) { try { if (NetworkInterface.getByInetAddress(p.getAddress()) != null) continue; } catch (Exception e) { } }
                Json j = new Json(new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8)); if (j.top == null || !"duck".equals(sget(j.top, "g"))) continue;
                Seen s = new Seen(); s.ip = p.getAddress().getHostAddress(); s.c = sget(j.top, "c"); s.hn = sget(j.top, "hn"); s.pc = iget(j.top, "pc"); s.port = iget(j.top, "p"); s.ts = System.currentTimeMillis();
                if (s.c.matches("\\d{4}") && iget(j.top, "ph") == 0) seen.put(s.ip + ":" + s.c, s); } catch (Exception e) { if (!run) break; } } });
        } catch (Exception e) { rx = null; }
        daemon("disc-tx", () -> { while (run) { sleep(1000); try { beacon(); } catch (Exception e) {} } });
    }
    void beacon() throws IOException {
        List<String[]> msgs = new ArrayList<>();
        synchronized (lock) { for (Room r : rooms.values()) if (hostConn(r) != null) msgs.add(new String[]{"{\"g\":\"duck\",\"c\":" + q(r.code) + ",\"hn\":" + q(r.hn) + ",\"pc\":" + r.pc + ",\"ph\":" + r.ph + ",\"p\":" + port + "}"}); }
        if (msgs.isEmpty()) return;
        List<InetSocketAddress> targets = new ArrayList<>();
        String forced = System.getProperty("duck.beaconTo");
        if (forced != null) { for (String t : forced.split(",")) { String[] hp = t.split(":"); targets.add(new InetSocketAddress(hp[0], Integer.parseInt(hp[1]))); } }
        else {
            int dport = Integer.getInteger("duck.disc", 8081);
            targets.add(new InetSocketAddress("255.255.255.255", dport));
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) if (ia.getBroadcast() != null) targets.add(new InetSocketAddress(ia.getBroadcast(), dport));
            }
        }
        try (DatagramSocket tx = new DatagramSocket()) {
            tx.setBroadcast(true);
            for (String[] m : msgs) { byte[] d = m[0].getBytes(StandardCharsets.UTF_8); for (InetSocketAddress t : targets) { try { tx.send(new DatagramPacket(d, d.length, t)); } catch (Exception e) {} } }
        }
    }

    // ------------------------------------------------------------------ JSON صغير
    static class Json {
        final String s; int i; Map<String, Object> top; String rawD;
        Json(String s) { this.s = s; ws(); Object o = val(0); top = o instanceof Map ? castMap(o) : null; }
        @SuppressWarnings("unchecked") static Map<String, Object> castMap(Object o) { return (Map<String, Object>) o; }
        void ws() { while (i < s.length() && s.charAt(i) <= ' ') i++; }
        Object val(int depth) {
            ws(); if (depth > 12) throw new RuntimeException("deep"); char c = s.charAt(i);
            if (c == '{') { i++; Map<String, Object> m = new HashMap<>(); ws(); if (s.charAt(i) == '}') { i++; return m; }
                for (;;) { ws(); String k = str(); ws(); if (s.charAt(i++) != ':') throw new RuntimeException(); ws(); int st = i; Object v = val(depth + 1); if (depth == 0 && k.equals("d")) rawD = s.substring(st, i); m.put(k, v); ws(); char d = s.charAt(i++); if (d == '}') return m; if (d != ',') throw new RuntimeException(); } }
            if (c == '[') { i++; List<Object> l = new ArrayList<>(); ws(); if (s.charAt(i) == ']') { i++; return l; }
                for (;;) { l.add(val(depth + 1)); ws(); char d = s.charAt(i++); if (d == ']') return l; if (d != ',') throw new RuntimeException(); } }
            if (c == '"') return str();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; } if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; } if (s.startsWith("null", i)) { i += 4; return null; }
            int st = i; while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++; if (st == i) throw new RuntimeException(); return Double.valueOf(s.substring(st, i));
        }
        String str() {
            if (s.charAt(i++) != '"') throw new RuntimeException(); StringBuilder b = new StringBuilder();
            for (;;) { char c = s.charAt(i++); if (c == '"') return b.toString();
                if (c == '\\') { char e = s.charAt(i++); switch (e) { case 'n': b.append('\n'); break; case 't': b.append('\t'); break; case 'r': b.append('\r'); break; case 'b': b.append('\b'); break; case 'f': b.append('\f'); break;
                    case 'u': b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break; default: b.append(e); } } else b.append(c); }
        }
    }

    // ------------------------------------------------------------------ تشغيل مستقل (للكمبيوتر)  java DuckServer.java 8080 index.html
    public static void main(String[] a) throws Exception {
        int port = a.length > 0 ? Integer.parseInt(a[0]) : 8080;
        byte[] html = a.length > 1 ? java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(a[1])) : "<html><head></head><body>Duck</body></html>".getBytes(StandardCharsets.UTF_8);
        new DuckServer(port, html).start(); System.out.println("Duck server on " + port); Thread.currentThread().join();
    }
}
